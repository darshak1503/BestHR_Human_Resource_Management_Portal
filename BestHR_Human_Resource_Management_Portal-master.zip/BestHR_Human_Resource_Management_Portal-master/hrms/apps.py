from django.apps import AppConfig


class HrmsConfig(AppConfig):
    name = 'hrms'
